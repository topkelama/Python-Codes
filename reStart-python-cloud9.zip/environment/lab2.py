myFruitlist = ["apple", "banana", "cherry"]
print(myFruitlist)
print(type(myFruitlist))
print("my favorite fruit is  "  + myFruitlist[2]) 