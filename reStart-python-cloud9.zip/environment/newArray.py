# newfruits = ["grape", "papaya", "peach", "watermellon"]
# newfruits[2] = "apple"
# print("my favorite fruit is: " + newfruits[2])
# print(type(newfruits))

# myDictionary = {
#     "Kami" : "apple",
#     "Biki" : "banana",
#     "sita" : "Kera",
#     "Pema" : "Amba",
#     "Chhum" : "cherry"
# }
# print(myDictionary)
# myTouple = ("apple", "banana", "pineapple", "guava", "Kera")
# print(myTouple)
# print(type(myTouple))
# myMixed = [45, 299876, 1.009, "My dog is cute", 44]
# for item in myMixed:
#     print("{} is of the data type {}".format(item, type(item)))
# 

# userReply = input("do you need to ship a pakage? enter Yes or No")
# if userReply == "yes":
#     print("we can help you ship that package")
# elif userReply == "no":
        
#     print("then tell me what can i help you with?")
# else:
#         print("bye")
import random
print("well come to the wrold of while loop")
number = random.randint(1,5)
isGuessRight = False
while isGuessRight != True:
    guess = input("guess a number between 1 and 10: ")
    if int(guess) == number:
        print("you guessed {}. that is correct! you win!".format(guess))
            
        
    
