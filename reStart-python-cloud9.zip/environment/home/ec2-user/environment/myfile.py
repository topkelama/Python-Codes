print("my world")
2+2